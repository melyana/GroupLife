﻿using System.Web;
using System.Web.Optimization;

namespace GroupLife
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery-{version}.js",
                        "~/Scripts/jquery-ui-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                        "~/Scripts/jquery.validate*"));

            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        "~/Scripts/modernizr-*"));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                      "~/Scripts/bootstrap.js",
                      "~/Scripts/bootstrap-datepicker.js",
                      "~/Scripts/respond.js",
                      "~/Scripts/bootstrap-hover-dropdown.js"));

            bundles.Add(new ScriptBundle("~/bundles/site").Include(
                        "~/Scripts/site.js"));

            bundles.Add(new ScriptBundle("~/bundles/toggleSidebar").Include(
                        "~/Scripts/ToggleSidebar.js",
                        "~/Scripts/toggleButton.js"));

            bundles.Add(new ScriptBundle("~/bundles/bootstrapValidator").Include(
                        "~/Scripts/bootstrapValidator.js"));

            bundles.Add(new ScriptBundle("~/bundles/gmap").Include(
                       "~/Scripts/jquery.gmap.js",
                       "~/Scripts/jquery.gmap_init.js"));

            bundles.Add(new ScriptBundle("~/bundles/modalform").Include(
                        "~/Scripts/modalform.js"));

            bundles.Add(new ScriptBundle("~/bundles/dataTables").Include(
                        "~/Scripts/jquery.dataTables.js",
                        "~/Scripts/dataTables.bootstrap.js"));

            bundles.Add(new ScriptBundle("~/bundles/general").Include(
                        "~/Scripts/general.js"));

            bundles.Add(new ScriptBundle("~/bundles/sb-admin").Include(
                        "~/Scripts/sb-admin-2.js",
                        "~/Scripts/metisMenu.js"));

            bundles.Add(new ScriptBundle("~/bundles/raphael").Include(
                        "~/Scripts/raphael.js",
                        "~/Scripts/raphael-min.js"));

            bundles.Add(new StyleBundle("~/Content/css").Include(
                      "~/Content/bootstrap.css",
                       "~/Content/jquery-ui.css",
                      "~/Content/bootstrap-datepicker3.css",
                      "~/Content/site.css",
                      "~/Content/datatables.bootstrap.css",
                      "~/Content/sb-admin-2.css",
                      "~/Content/morris.css",
                      "~/Content/font-awesome.css",
                      "~/Content/toggleSidebar.css",
                      "~/Content/metisMenu.css"));



            // Set EnableOptimizations to false for debugging. For more information,
            // visit http://go.microsoft.com/fwlink/?LinkId=301862
            BundleTable.EnableOptimizations = true;
        }
    }
}
