﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;

namespace GroupLife.Common
{
    
    public class AuditTrails
    {
        public void ActLogs(IGLEntities db, string activityName, object oldData, object newData)
        {
            //var props[] = oldData.GetType().GetProperties();

            PropertyInfo[] oldprops = oldData.GetType().GetProperties()
                .Where(p => !p.GetGetMethod().IsVirtual).ToArray();

            string old = "";

            foreach (var prop in oldprops)
            {
                try
                {
                    old += prop.GetValue(oldData, null).ToString() + "#";
                }
                catch (Exception e)
                {
                    old += "---#";
                }
            }

            old.TrimEnd('#');

            PropertyInfo[] newprops = newData.GetType().GetProperties()
                .Where(p => !p.GetGetMethod().IsVirtual).ToArray();

            string news = "";

            foreach (var prop in newprops)
            {
                try
                {
                    news += prop.GetValue(newData, null).ToString() + "#";
                }
                catch(Exception e)
                {
                    news += "---#";
                }
            }

            old.TrimEnd('#');

            string[] rawtype = oldData.GetType().ToString().Split('.');
            string[] rawFormName = rawtype[rawtype.Length - 1].Split('_');
            string formName = rawFormName[0];

            var Username = HttpContext.Current.Session["UserName"] != null || HttpContext.Current.Session["UserName"].ToString() != ""
                ? HttpContext.Current.Session["UserName"].ToString()
                : "0";

            int userId = db.SysUsers.Where(x => x.Username == Username).Select(p => p.ID).FirstOrDefault();
            SysAuditTrail audit = new SysAuditTrail();
            audit.Activity = activityName + "  " + formName;
            audit.OldData = old;
            audit.NewData = news;
            audit.TableName = formName;
            audit.Date = DateTime.Now;
            audit.UserID = userId;
            db.SysAuditTrails.Add(audit);
            db.SaveChanges();
        }

    }
}