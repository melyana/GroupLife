﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Cryptography;
using GroupLife.Models;


namespace GroupLife.Common
{
    public class ControlAuth
    {
        public bool CheckControl(string formName, int controlID, IGLEntities db)
        {
            var controls = getUsedControl(formName, db);
            var control = controls.Where(x => x.ControlID == controlID);
            if (control != null)
            {
                return true;
            }
            return false;
        }

        public List<SysPrivilegeControl> getUsedControl(string formName, IGLEntities db)
        {
            var groupId = HttpContext.Current.Session["GroupID"] != null || HttpContext.Current.Session["GroupID"].ToString() != ""
                ? HttpContext.Current.Session["GroupID"].ToString()
                : "0";

            var form = db.SysForms.Where(x => x.nameOption.Equals(formName)).FirstOrDefault();
            var controls = db.SysPrivilegeControls.AsEnumerable().Where(s => s.GroupID.ToString().Equals(groupId))
                .Where(p => p.FormID == form.Id).ToList();

            return controls;
        }

        public AllowedControls getAllowedControl(string formName, IGLEntities db)
        {
            AllowedControls model = new AllowedControls();
            var controls = getUsedControl(formName, db).Select(x => x.ControlID).ToArray();

            if (controls.Contains(1))
            {
                model.Add = true;
            }
            if (controls.Contains(2))
            {
                model.Edit = true;
            }
            if (controls.Contains(3))
            {
                model.Delete = true;
            }
            if (controls.Contains(5))
            {
                model.Control = true;
            }

            return model;
        }
    }
}