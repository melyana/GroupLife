﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.DirectoryServices;
using System.Text;
using System.Configuration;
using System.Reflection;
using System.Text.RegularExpressions;

namespace GroupLife.Controllers
{
    public class LdapAuth
    {
        private string _path;
        private string _domain;
        private string _filterAttribute;
        private DirectoryEntry entry;

        public LdapAuth()
        {
            _path = ConfigurationManager.AppSettings["LDAPPath"];
            _domain = ConfigurationManager.AppSettings["LDAPDomain"];
        }

        public bool IsAuthenticated(string username, string pwd)
        {
            string domainAndUsername = _domain + @"\" + username;
            entry = new DirectoryEntry(_path, domainAndUsername, pwd);
            bool res = false;

            try
            {
                //Bind to the native AdsObject to force authentication.
                object obj = entry.NativeObject;

                DirectorySearcher search = new DirectorySearcher(entry);

                search.Filter = "(SAMAccountName=" + username + ")";
                search.PropertiesToLoad.Add("cn");
                SearchResult result = search.FindOne();

                if (result == null)
                {
                    res = false;
                }
                else
                {
                    //Update the new path to the user in the directory.
                    _path = result.Path;
                    _filterAttribute = (string)result.Properties["cn"][0];

                    res = true;
                }
            }
            catch (Exception ex)
            {
                res = false;
                //throw;
                //throw new Exception("Error authenticating user. " + ex.Message);
            }

            return res;
        }

        public bool ChangePasswordAD(string oldPassword, string newPassword, string domainName, string userName)
        {
            bool res = false;
            try
            {
                DirectoryEntry directionEntry = new DirectoryEntry(_path, domainName + "\\" + userName, oldPassword);
                if (directionEntry != null)

                {
                    DirectorySearcher search = new DirectorySearcher(directionEntry);
                    search.Filter = "(SAMAccountName=" + userName + ")";
                    SearchResult result = search.FindOne();
                    if (result != null)
                    {
                        DirectoryEntry userEntry = result.GetDirectoryEntry();
                        if (userEntry != null)
                        {
                            userEntry.Invoke("SetPassword", new object[] { newPassword });
                            userEntry.Properties["LockOutTime"].Value = 0; //unlock account

                            userEntry.Close();

                            //userEntry.Invoke("ChangePassword", new object[] { oldPassword, newPassword });
                            //userEntry.CommitChanges();

                            res = true;
                        }
                    }
                }
            }
            catch (TargetInvocationException ex)
            {
                res = false;
                string errorMessage = ex.InnerException.ToString();
                throw ex;
            }

            return res;
        }

        private string GetProperty(String propertyName)
        {
            if (entry.Properties.Contains(propertyName))
            {
                return entry.Properties[propertyName][0].ToString();
            }
            else
            {
                return string.Empty;
            }
        }

        public string GetUsername()
        {
            return GetProperty("sAMAccountName");
        }

        public string GetDomain()
        {
            string domainAddress = "";

            String userPrincipalName = GetProperty("distinguishedName");
            if (!string.IsNullOrEmpty(userPrincipalName))
            {
                string[] arr = Regex.Split(userPrincipalName, "DC=");

                foreach (string ar in arr)
                {
                    domainAddress += ar != "" ? ar.TrimEnd(',') + "." : "";
                }
            }
            else
            {
                domainAddress = String.Empty;
            }

            return domainAddress.TrimEnd('.');
        }

        public string GetFirstName()
        {
            return GetProperty("givenName");
        }

        public string GetLastName()
        {
            return GetProperty("sn");
        }

        public string GetGroups()
        {
            DirectorySearcher search = new DirectorySearcher(_path);
            search.Filter = "(cn=" + _filterAttribute + ")";
            search.PropertiesToLoad.Add("memberOf");
            StringBuilder groupNames = new StringBuilder();

            try
            {
                SearchResult result = search.FindOne();
                int propertyCount = result.Properties["memberOf"].Count;
                string dn;
                int equalsIndex, commaIndex;

                for (int propertyCounter = 0; propertyCounter < propertyCount; propertyCounter++)
                {
                    dn = (string)result.Properties["memberOf"][propertyCounter];
                    equalsIndex = dn.IndexOf("=", 1);
                    commaIndex = dn.IndexOf(",", 1);
                    if (-1 == equalsIndex)
                    {
                        return null;
                    }
                    groupNames.Append(dn.Substring((equalsIndex + 1), (commaIndex - equalsIndex) - 1));
                    groupNames.Append("|");
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error obtaining group names. " + ex.Message);
            }
            return groupNames.ToString();
        }
    }
}