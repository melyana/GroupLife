﻿$(document).ready(function () {
    try {
        var path = location.pathname;
        $('.navbar-nav > li a[href="' + path + '"]').closest('li').addClass('active');
        $('.menu-container-item > li a[href="' + path + '"]').closest('li').addClass('active');

        initDataTables();

    } catch (e) {
        alert(e);
    }
});

function initDataTables() {
    var init = {};

    $('.dataTable').each(function () {
        if ($(this).hasClass('no-sort')) init["bSort"] = false;
        if ($(this).hasClass('scroll-horizontal')) init["scrollX"] = true;
        if ($(this).hasClass('no-search')) init["bFilter"] = false;

        $(this).DataTable(
            init
        );
    });
}

function checkAll(obj) {
    try {
        var isChecked = $(obj).is(':checked');
        var table = $(obj).parents('table');

        var trs = $(table).find("tbody").find("input[type=checkbox]");

        $(trs).prop('checked', isChecked);
    } catch (e) {
        //alert(e);
    }
}