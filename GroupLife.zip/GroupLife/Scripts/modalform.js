﻿$(function () {

    $.ajaxSetup({ cache: false });

    $("a[data-modal]").on("click", function (e) {
        
        // hide dropdown if any
        $(e.target).closest('.btn-group').children('.dropdown-toggle').dropdown('toggle');

        $('#myModalContent').load(this.href, function () {
            if ($('.datepicker').length > 0) {
                $('.datepicker').datepicker({
                    format: "dd/mm/yyyy",
                    autoclose: true
                });
            }

            $('#myModal').modal({
                /*backdrop: 'static',*/
                keyboard: true
            }, 'show');

            bindForm(this);
        });
        
        return false;
    });


});

$('#myModal').on('shown.bs.modal', function () {
    /*
    var dv = $(".divScrollCheckBox");
    var label = $(dv).find('label');
    
    $.each(label, function () {
        $(this).after("<br>");
    });
    */
})

function bindForm(dialog) {
    
    $('form', dialog).submit(function () {
        var url = $(this).attr('action');
        var method = this.method;
        var data = $(this).serialize();

        var msg = "url=" + url + "&type=" + method;
        console.log(msg);

        $.ajax({
            url: url,
            type: this.method,
            data: $(this).serialize(),
            success: function (result) {
                if (result.success) {
                    $('#myModal').modal('hide');
                    //Refresh
                    location.reload();
                } else {
                    $('#myModalContent').html(result);
                    bindForm();
                }
            }
        });
        return false;
    });
}

function submitModal(obj) {
    try {
        //alert(this.herf);
        //$.ajaxSetup({ cache: false });

        //// hide dropdown if any
        ////$(obj.target).closest('.btn-group').children('.dropdown-toggle').dropdown('toggle');
        //$(obj.target).closest('.btn-group').children('.dropdown-toggle').dropdown('toggle');
        //alert(this.href);
        $('#myModalContent').load("http://localhost:61430/SysUser/MultipleEdit", function () {


            $('#myModal').modal({
                /*backdrop: 'static',*/
                keyboard: true
            }, 'show');

            bindForm2(this);
        });

        return false;

    } catch (e) {
        alert(e);
    }
};

function showModal(obj) {
    try {

        $.ajaxSetup({ cache: false });

        // hide dropdown if any
        //$(obj.target).closest('.btn-group').children('.dropdown-toggle').dropdown('toggle');
       
        $('#myModalContent2').load(obj.href, function () {


            $('#myModal2').modal({
                /*backdrop: 'static',*/
                keyboard: true
            }, 'show');

            bindForm2(this);
        });

        return false;

    } catch (e) {
        alert(e);
    }
};

function bindForm2(dialog) {

    $('form', dialog).submit(function () {
        $.ajax({
            url: this.action,
            type: this.method,
            data: $(this).serialize(),
            success: function (result) {
                if (result.success) {
                    $('#myModal2').modal('hide');
                    //Refresh
                    location.reload();
                } else {
                    $('#myModalContent2').html(result);
                    bindForm();
                }
            }
        });
        return false;
    });
}
