﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GroupLife.Models
{
    public class SysGroupControlViewModel
    {
        public SysGroup SysGroup { get; set;  }
        public IEnumerable<SysForm> SysForm { get; set; }
    }
}