﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GroupLife;

namespace GroupLife.Models
{
    public class SysModuleViewModel
    {
        public SysModule SysModule { get; set; }
        public SysForm SysForm { get; set; }
        public SysFormListModel SysFormList { get; set; }
    }
}