﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GroupLife.Models
{
    public class SysControlListModel
    {
        public IEnumerable<SysControl> AvailableControls { get; set; }
        public IEnumerable<SysControl> SelectedControls { get; set; }
        public PostedControl PostedConbtrol { get; set; }
    }

    public class PostedControl
    {
        public string[] ControlIds { get; set; }
    }
}