﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GroupLife.Models
{
    public class SysGroupViewModel
    {
        public SysGroup SysGroup { get; set; }
        public SysModule SysModule { get; set; }
        public SysModuleListModel SysModuleList { get; set; }
    }
}