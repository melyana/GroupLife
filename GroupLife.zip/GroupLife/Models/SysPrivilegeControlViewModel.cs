﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GroupLife.Models
{
    public class SysPrivilegeControlViewModel
    {
        public SysGroup SysGroup { get; set; }
        public SysForm SysForm { get; set; }
        public SysPrivilegeControl PrivilegeControl { get; set;  }
        public SysFormListModel SysMenuListModel { get; set; }
        public SysControlListModel SysControlListModel { get; set; }
    }
}