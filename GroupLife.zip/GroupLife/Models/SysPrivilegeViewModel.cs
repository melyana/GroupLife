﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GroupLife.Models
{
    public class SysPrivilegeViewModel
    {
        public SysPrivilege SysPrivilege { get; set; }
        public SysModule SysModule { get; set; }
        public SysModuleListModel SysModuleList { get; set; }
    }
}