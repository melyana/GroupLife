﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GroupLife;

namespace GroupLife.Models
{
    public class SysFormListModel
    {
        public IEnumerable<SysForm> AvailableForms { get; set; }
        public IEnumerable<SysForm> SelectedForms { get; set; }
        public PostedForm PostedForm { get; set; }
    }

    public class PostedForm
    {
        public string[] FormIds { get; set; }
    }
}