﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GroupLife.Models
{
    public class AllowedControls
    {
        public AllowedControls()
        {
            this.Add = false;
            this.Control = false;
            this.Delete = false;
            this.Detail = false;
            this.Edit = false;
        }
        public bool Add { get; set; }
        public bool Edit { get; set; }
        public bool Delete { get; set; }
        public bool Control { get; set; }
        public bool Detail { get; set; }
    }
}