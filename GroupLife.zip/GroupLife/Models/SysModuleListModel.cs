﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GroupLife;

namespace GroupLife.Models
{
    public class SysModuleListModel
    {
        public IEnumerable<SysModule> AvailableModules { get; set;  }
        public IEnumerable<SysModule> SelectedModules { get; set; }
        public PostedModules PostedModules { get; set; }

    }

    public class PostedModules
    {
        public string[] ModuleIds { get; set; }
    }
}