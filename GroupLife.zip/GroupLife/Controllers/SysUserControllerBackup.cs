﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using GroupLife;

namespace GroupLife.Controllers
{
    public class SysUserControllerBackup : Controller
    {
        private IGLEntities db = new IGLEntities();

        // GET: /SysUser/
        public async Task<ActionResult> Index()
        {
            var sysusers = db.SysUsers.Include(s => s.SysPrivilege).Include(s => s.SysUserType);
            return View(await sysusers.ToListAsync());
        }

        // GET: /SysUser/Details/5
        public async Task<ActionResult> Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysUser sysuser = await db.SysUsers.FindAsync(id);
            if (sysuser == null)
            {
                return HttpNotFound();
            }
            return View(sysuser);
        }

        // GET: /SysUser/Create
        public ActionResult Create()
        {
            ViewBag.GroupID = new SelectList(db.SysPrivileges, "GroupID", "FCode");
            ViewBag.Type = new SelectList(db.SysUserTypes, "TypeID", "Type");
            return PartialView("_Create");
        }

        // POST: /SysUser/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include="ID,GroupID,Domain,Name,Password,Type,Validation,Expiry,LockedF,Password_Expiry,Title,Signature,LogAttempt,RestoreLimit")] SysUser sysuser)
        {
            if (ModelState.IsValid)
            {
                db.SysUsers.Add(sysuser);
                await db.SaveChangesAsync();
                return Json(new { success = true });
            }

            ViewBag.GroupID = new SelectList(db.SysPrivileges, "GroupID", "FCode", sysuser.GroupID);
            ViewBag.Type = new SelectList(db.SysUserTypes, "TypeID", "Type", sysuser.Type);
            return PartialView("_Create", sysuser);
        }

        // GET: /SysUser/Edit/5
        public async Task<ActionResult> Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysUser sysuser = await db.SysUsers.FindAsync(id);
            if (sysuser == null)
            {
                return HttpNotFound();
            }
            ViewBag.GroupID = new SelectList(db.SysPrivileges, "GroupID", "FCode", sysuser.GroupID);
            ViewBag.Type = new SelectList(db.SysUserTypes, "TypeID", "Type", sysuser.Type);
            return PartialView("_Edit", sysuser);
        }

        // POST: /SysUser/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include="ID,GroupID,Domain,Name,Password,Type,Validation,Expiry,LockedF,Password_Expiry,Title,Signature,LogAttempt,RestoreLimit")] SysUser sysuser)
        {
            if (ModelState.IsValid)
            {
                db.Entry(sysuser).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return Json(new { success = true });
            }
            ViewBag.GroupID = new SelectList(db.SysPrivileges, "GroupID", "FCode", sysuser.GroupID);
            ViewBag.Type = new SelectList(db.SysUserTypes, "TypeID", "Type", sysuser.Type);
            return PartialView("_Edit", sysuser);
        }

        // GET: /SysUser/Delete/5
        public async Task<ActionResult> Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysUser sysuser = await db.SysUsers.FindAsync(id);
            if (sysuser == null)
            {
                return HttpNotFound();
            }
            return PartialView("_Delete", sysuser);
        }

        // POST: /SysUser/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(string id)
        {
            SysUser sysuser = await db.SysUsers.FindAsync(id);
            db.SysUsers.Remove(sysuser);
            await db.SaveChangesAsync();
            return Json(new { success = true });
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
