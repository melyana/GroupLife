﻿using System;
using System.Collections.Generic;
using System.Data;

using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using GroupLife;
using GroupLife.Common;
using Cryptography;

namespace GroupLife.Controllers
{
    public class SysUserController : Controller
    {
        private IGLEntities db = new IGLEntities();
        private ControlAuth ca = new ControlAuth();
        private AuditTrails at = new AuditTrails();
        private static string[] userIds;

        // GET: /SysUser/
        public async Task<ActionResult> Index(string searchUsername)
        {
            ViewBag.allowedControls = ca.getAllowedControl("User", db);
            var sysusers = db.SysUsers.Include(s => s.SysGroup).Include(s => s.SysUserType);
 
            if(!String.IsNullOrEmpty(searchUsername))
            {
                sysusers = sysusers.Where(s => s.Username.Contains(searchUsername));
                
            }
            if (!ca.CheckControl("User", 4, db))
            {
                return View("NotPermitted");
            }
            return View(await sysusers.ToListAsync());
        }

        [HttpPost]
        public ActionResult MultipleEdit(FormCollection form)
        {
            userIds = null;
            if (form.GetValues("selectedAddressesIds") != null)
            {
                ViewBag.GroupID = new SelectList(db.SysGroups, "GroupID", "GroupName");
                ViewBag.Type = new SelectList(db.SysUserTypes, "TypeID", "Type");
                userIds = form.GetValues("selectedAddressesIds").ToArray();
            
                return View("MultipleEdit");
            }

            ViewBag.allowedControls = ca.getAllowedControl("User", db);
            return RedirectToAction("Index", "SysUser");

        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> MultipleEditDone(SysUser sysuser)
        {
            foreach(string userId in userIds)
            {
                SysUser user = db.SysUsers.Find(int.Parse(userId));
                user.Expiry = sysuser.Expiry;
                user.Password_Expiry = sysuser.Password_Expiry;
                user.LogAttempt = sysuser.LogAttempt;
                user.Type = sysuser.Type;
                db.Entry(user).State = EntityState.Modified;
                await db.SaveChangesAsync();
            }
            userIds = null;
            return View("Index", await db.SysUsers.ToListAsync());
        }

        // GET: /SysUser/Details/5
        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysUser sysuser = await db.SysUsers.FindAsync(id);
            if (sysuser == null)
            {
                return HttpNotFound();
            }
            return View(sysuser);
        }

        // GET: /SysUser/Create
        public ActionResult Create()
        {
            ViewBag.GroupID = new SelectList(db.SysGroups, "GroupID", "GroupName");
            ViewBag.Type = new SelectList(db.SysUserTypes, "TypeID", "Type");
            SysUser sysuser = new SysUser();
            sysuser.Password = GeneratePassword();
            if (!ca.CheckControl("User", 1, db))
            {
                return View("NotPermitted");
            }
            return PartialView("_Create", sysuser);
        }

        // POST: /SysUser/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include="ID,Username,GroupID,Name,Password,Email,Type,Validation,Expiry,LockedF,Password_Expiry,Title,Signature,LogAttempt,RestoreLimit")] SysUser sysuser)
        {
            if (ModelState.IsValid)
            {
                AES_Cryptography crypto = new AES_Cryptography();
                string pass = sysuser.Password;
                string pass_enc = crypto.encryptString(sysuser.Password);

                sysuser.Password = pass_enc;
                at.ActLogs(db, "Create", new SysUser(), sysuser);
                sysuser.FirstLogin = true;
                db.SysUsers.Add(sysuser);
                await db.SaveChangesAsync();
                sysuser.Password = pass;
                sendEmail(sysuser);
                return Json(new { success = true });
            }

            ViewBag.GroupID = new SelectList(db.SysGroups, "GroupID", "GroupName", sysuser.GroupID);
            ViewBag.Type = new SelectList(db.SysUserTypes, "TypeID", "Type", sysuser.Type);
            return PartialView("_Create", sysuser);
        }

        // GET: /SysUser/Edit/5
        public async Task<ActionResult> Edit(int? id)
        {
            AES_Cryptography crypto = new AES_Cryptography();

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysUser sysuser = await db.SysUsers.FindAsync(id);
            sysuser.Password = crypto.decryptString(sysuser.Password);
            if (sysuser == null)
            {
                return HttpNotFound();
            }
            ViewBag.GroupID = new SelectList(db.SysGroups, "GroupID", "GroupName", sysuser.GroupID);
            ViewBag.Type = new SelectList(db.SysUserTypes, "TypeID", "Type", sysuser.Type);
            if (!ca.CheckControl("User", 2, db))
            {
                return View("NotPermitted");
            }
            return PartialView("_Edit", sysuser);
        }

        // POST: /SysUser/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include="ID,Username,GroupID,Name,Password,Email,Type,Validation,Expiry,LockedF,Password_Expiry,Title,Signature,LogAttempt,RestoreLimit")] SysUser sysuser)
        {
            if (ModelState.IsValid)
            {
                AES_Cryptography crypto = new AES_Cryptography();
                string pass_enc = crypto.encryptString(sysuser.Password);

                SysUser sysUser = db.SysUsers.Find(sysuser.ID);
                sysUser.Password = pass_enc;
                at.ActLogs(db, "Editing", sysUser, sysuser);
                db.Entry(sysuser).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return Json(new { success = true });
            }
            ViewBag.GroupID = new SelectList(db.SysGroups, "GroupID", "GroupName", sysuser.GroupID);
            ViewBag.Type = new SelectList(db.SysUserTypes, "TypeID", "Type", sysuser.Type);
            return PartialView("_Edit", sysuser);
        }

        // GET: /SysUser/Delete/5
        public async Task<ActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysUser sysuser = await db.SysUsers.FindAsync(id);
            if (sysuser == null)
            {
                return HttpNotFound();
            }
            if (!ca.CheckControl("User", 3, db))
            {
                return View("NotPermitted");
            }
            return PartialView("_Delete", sysuser);
        }

        // POST: /SysUser/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int? id)
        {
            SysUser sysUser = await db.SysUsers.FindAsync(id);

            at.ActLogs(db, "Delete", sysUser, new SysUser());
           
            SysUser sysuser = await db.SysUsers.FindAsync(id);
            db.SysUsers.Remove(sysuser);
            await db.SaveChangesAsync();
            return Json(new { success = true });
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
        
        public string GeneratePassword()
        {
            // TODO Generate Random Password to new User
            string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            var random = new Random();

            return new string(Enumerable.Repeat(chars, 10)
                .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        public void sendEmail(SysUser sysuser)
        {
            SmtpMail smtpmail = new SmtpMail();
            string body = "<p>This is your username : " + sysuser.Username + "</p>";
            body += "<p>This is your password : " + sysuser.Password + "</p>";
            smtpmail.SendMail(sysuser.Email, "", "", "Confirmation", body);
        }
    }
}
