﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using GroupLife;
using GroupLife.Models;

namespace GroupLife.Controllers
{
    public class SysPrivilegeController : Controller
    {
        private IGLEntities db = new IGLEntities();

        // GET: /SysPrivilege/
        public async Task<ActionResult> Index()
        {
            var sysprivileges = db.SysPrivileges.Include(s => s.SysGroup).Include(s => s.SysModule);
            return View(await sysprivileges.ToListAsync());
        }

        // GET: /SysPrivilege/Details/5
        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysPrivilege sysprivilege = await db.SysPrivileges.FindAsync(id);
            if (sysprivilege == null)
            {
                return HttpNotFound();
            }
            return View(sysprivilege);
        }

        // GET: /SysPrivilege/Create
        public ActionResult Create()
        {
            ViewBag.GroupID = new SelectList(db.SysGroups, "GroupID", "GroupName");
            ViewBag.ModuleID = new SelectList(db.SysModules, "ModuleID", "ModuleName");

            SysPrivilegeViewModel sysprivilege = new SysPrivilegeViewModel();
            sysprivilege.SysModule = new SysModule();
            
            return PartialView("_Create", sysprivilege);
        }

        // POST: /SysPrivilege/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include="PrivID,ModuleID,PrivName,Description,GroupID")] SysPrivilege sysprivilege)
        {
            if (ModelState.IsValid)
            {
                db.SysPrivileges.Add(sysprivilege);
                await db.SaveChangesAsync();
                return Json(new { success = true });
            }

            ViewBag.GroupID = new SelectList(db.SysGroups, "GroupID", "GroupName", sysprivilege.GroupID);
            ViewBag.ModuleID = new SelectList(db.SysModules, "ModuleID", "ModuleName", sysprivilege.ModuleID);
            return PartialView("_Create", sysprivilege);
        }

        // GET: /SysPrivilege/Edit/5
        public async Task<ActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysPrivilege sysprivilege = await db.SysPrivileges.FindAsync(id);
            if (sysprivilege == null)
            {
                return HttpNotFound();
            }
            ViewBag.GroupID = new SelectList(db.SysGroups, "GroupID", "GroupName", sysprivilege.GroupID);
            ViewBag.ModuleID = new SelectList(db.SysModules, "ModuleID", "ModuleName", sysprivilege.ModuleID);
            return PartialView("_Edit", sysprivilege);
        }

        // POST: /SysPrivilege/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include="PrivID,ModuleID,PrivName,Description,GroupID")] SysPrivilege sysprivilege)
        {
            if (ModelState.IsValid)
            {
                db.Entry(sysprivilege).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return Json(new { success = true });
            }
            ViewBag.GroupID = new SelectList(db.SysGroups, "GroupID", "GroupName", sysprivilege.GroupID);
            ViewBag.ModuleID = new SelectList(db.SysModules, "ModuleID", "ModuleName", sysprivilege.ModuleID);
            return PartialView("_Edit", sysprivilege);
        }

        // GET: /SysPrivilege/Delete/5
        public async Task<ActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysPrivilege sysprivilege = await db.SysPrivileges.FindAsync(id);
            if (sysprivilege == null)
            {
                return HttpNotFound();
            }
            return PartialView("_Edit", sysprivilege);
        }

        // POST: /SysPrivilege/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            SysPrivilege sysprivilege = await db.SysPrivileges.FindAsync(id);
            db.SysPrivileges.Remove(sysprivilege);
            await db.SaveChangesAsync();
            return Json(new { success = true });
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private SysFormListModel initializeMenuList()
        {
            SysFormListModel model = new SysFormListModel();
            model.AvailableForms = db.SysForms;

            return model;
        }

        private SysControlListModel initializeControlList()
        {
            SysControlListModel model = new SysControlListModel();
            model.AvailableControls = db.SysControls;

            return model;
        }


    }
}
