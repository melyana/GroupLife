﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using GroupLife;
using GroupLife.Common;

namespace GroupLife.Controllers
{
    public class SysFormController : Controller
    {
        private IGLEntities db = new IGLEntities();
        private ControlAuth ca = new ControlAuth();
        private AuditTrails at = new AuditTrails();

        // GET: /Menu/
        public async Task<ActionResult> Index(string searchFormName)
        {
            ViewBag.allowedControls = ca.getAllowedControl("Form", db);

            var sysForm = from form in db.SysForms
                              select form;

            if (!String.IsNullOrEmpty(searchFormName))
            {
                sysForm = sysForm.Where(s => s.nameOption.Contains(searchFormName));
            }

            if(!ca.CheckControl("Form", 4, db))
            {
                return View("NotPermitted");
            }

            return View(await sysForm.ToListAsync());
        }
        
        // GET: /Menu/Details/5
        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysForm sysform = await db.SysForms.FindAsync(id);
            if (sysform == null)
            {
                return HttpNotFound();
            }
            return View(sysform);
        }

        // GET: /Menu/Create
        public ActionResult Create()
        {
            ViewBag.parentId = new SelectList(getParentList(), "Id", "nameOption");
            return PartialView("_Create");
            //return View();
        }

        private List<SysForm> getParentList()
        {
            List<SysForm> parentList = db.SysForms.Where(s => s.isParent == true).ToList();
            parentList.Insert(0, new SysForm
            {
                Id = 0,
                nameOption = "None"
            });

            return parentList;
        }

        // POST: /Menu/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(SysForm sysform)
        {
            if (ModelState.IsValid)
            {
                db.SysForms.Add(sysform);
                await db.SaveChangesAsync();
                at.ActLogs(db, "Create", new SysModule(), sysform);
                return Json(new { success = true });
                //return RedirectToAction("Index");
            }

            return PartialView("_Create",sysform);
            //return View(sysform);
        }

        // GET: /SysForm/Edit/5
        public async Task<ActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysForm sysform = await db.SysForms.FindAsync(id);
            if (sysform == null)
            {
                return HttpNotFound();
            }
            ViewBag.parentId = new SelectList(getParentList(), "Id", "nameOption", sysform.parentId);
            return View(sysform);
        }

        // POST: /Menu/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include="Id,nameOption,controller,action,area,imageClass,activeli,status,parentId,isParent,sequence")] SysForm sysform)
        {
            if (ModelState.IsValid)
            {
                SysModule SYSform = db.SysModules.Find(sysform.Id);
                at.ActLogs(db, "Editing", db.SysForms.Find(sysform.Id), SYSform);
                db.Entry(sysform).State = EntityState.Modified;
                await db.SaveChangesAsync();
                
                return RedirectToAction("Index");
            }
            return View(sysform);
        }

        // GET: /Menu/Delete/5
        public async Task<ActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysForm sysform = await db.SysForms.FindAsync(id);
            if (sysform == null)
            {
                return HttpNotFound();
            }
            return View(sysform);
        }

        // POST: /Menu/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            //SysModule sysmodule = await db.SysModules.FindAsync(ModuleID);
            
            SysForm sysform = await db.SysForms.FindAsync(id);
            at.ActLogs(db, "Delete", sysform, new SysForm());
            db.SysForms.Remove(sysform);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);          
        }
    }
}
