﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using GroupLife;
using GroupLife.Common;
using GroupLife.Models;

namespace GroupLife.Controllers
{
    public class SysModuleController : Controller
    {
        private IGLEntities db = new IGLEntities();
        private ControlAuth ca = new ControlAuth();
        private AuditTrails at = new AuditTrails();

        // GET: /SysModule/
        public async Task<ActionResult> Index(string searchModuleName)
        {
            ViewBag.allowedControls = ca.getAllowedControl("Module", db);
            var sysModule = from module in db.SysModules
                       select module;

            if (!String.IsNullOrEmpty(searchModuleName))
            {
                sysModule = sysModule.Where(s => s.ModuleName.Contains(searchModuleName));
            }

            if (!ca.CheckControl("Module", 4, db))
            {
                return View("NotPermitted");
            }

            return View(await sysModule.ToListAsync());
        }

        // GET: /SysModule/Details/5
        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysModule sysmodule = await db.SysModules.FindAsync(id);
            if (sysmodule == null)
            {
                return HttpNotFound();
            }
            return View(sysmodule);
        }

        // GET: /SysModule/Create
        public ActionResult Create()
        {
            SysModuleViewModel sysModuleViewModel = new SysModuleViewModel();
            sysModuleViewModel.SysFormList = intializeFormList();
            sysModuleViewModel.SysForm = new SysForm();
            sysModuleViewModel.SysModule = new SysModule();

            return PartialView("_Create", sysModuleViewModel);
        }

        // POST: /SysModule/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(SysModuleViewModel sysModuleViewModel)
        {
            //if (ModelState.IsValid)
            //{
           
            SysModule sysmodule = sysModuleViewModel.SysModule;
                db.SysModules.Add(sysmodule);
                await db.SaveChangesAsync();
            at.ActLogs(db, "Create", new SysModule(), sysmodule);
            foreach (string formId in sysModuleViewModel.SysFormList.PostedForm.FormIds)
                {
                    SysModuleForm moduleForm = new SysModuleForm();
                    moduleForm.ModuleID = sysmodule.ModuleID;
                    moduleForm.FormID = int.Parse(formId);
                    db.SysModuleForms.Add(moduleForm);
                    await db.SaveChangesAsync();
                }
                return Json(new { success = true });
            //}

            //return PartialView("_Create", sysmodule);
        }

        // GET: /SysModule/Edit/5
        public async Task<ActionResult> Edit(int? ModuleID)
        {
            if (ModuleID == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysModule sysmodule = await db.SysModules.FindAsync(ModuleID);
            SysModuleViewModel sysModuleViewModel = getModuleViewModel(sysmodule.ModuleID);
            if (sysmodule == null)
            {
                return HttpNotFound();
            }
            return PartialView("_Edit", sysModuleViewModel);
        }

        // POST: /SysModule/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(SysModuleViewModel sysModuleViewModel)
        {
            //if (ModelState.IsValid)
            //{
            SysModule sysModule = db.SysModules.Find(sysModuleViewModel.SysModule.ModuleID);
            at.ActLogs(db, "Editing", sysModule, sysModuleViewModel.SysModule);
            db.Entry(sysModule).State = EntityState.Modified;
                await db.SaveChangesAsync();
                db.SysModuleForms.RemoveRange(db.SysModuleForms.Where(c => c.ModuleID == sysModuleViewModel.SysModule.ModuleID));
                await db.SaveChangesAsync();
                foreach (string formId in sysModuleViewModel.SysFormList.PostedForm.FormIds)
                {
                    SysModuleForm moduleForm = new SysModuleForm();
                    moduleForm.ModuleID = sysModule.ModuleID;
                    moduleForm.FormID = int.Parse(formId);
                    db.SysModuleForms.Add(moduleForm);
                    await db.SaveChangesAsync();
                }

            return Json(new { success = true });
            //}
            //return PartialView("_Edit", sysmodule);
        }

        // GET: /SysModule/Delete/5
        public async Task<ActionResult> Delete(int? ModuleID)
        {
            if (ModuleID == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysModule sysmodule = await db.SysModules.FindAsync(ModuleID);
            if (sysmodule == null)
            {
                return HttpNotFound();
            }
            return PartialView("_Delete", sysmodule);
        }

        // POST: /SysModule/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int ModuleID)
        {
            SysModule sysmodule = await db.SysModules.FindAsync(ModuleID);
            at.ActLogs(db, "Delete", sysmodule, new SysModule());
            db.SysModuleForms.RemoveRange(db.SysModuleForms.Where(c => c.ModuleID == ModuleID));
            await db.SaveChangesAsync();
            db.SysModules.Remove(sysmodule);
            await db.SaveChangesAsync();
            return Json(new { success = true });
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private SysFormListModel intializeFormList()
        {
            SysFormListModel model = new SysFormListModel();
            model.AvailableForms = db.SysForms.Where(s => s.isParent == false);

            return model;
        }

        private SysModuleViewModel getModuleViewModel(int id)
        {
            var model = new SysModuleViewModel();
            model.SysFormList = new SysFormListModel();
            model.SysFormList.PostedForm = new PostedForm();

            string[] formIds = getFormIds(id);

            if (formIds != null && formIds.Any())
            {
                model.SysFormList.PostedForm.FormIds = formIds;

                model.SysFormList.SelectedForms = db.SysForms
                    .Where(x => formIds.Contains(x.Id.ToString()));
            }
            model.SysFormList.AvailableForms = db.SysForms.Where(s => s.isParent==false);
            model.SysModule = db.SysModules.Find(id);

            return model;
        }

        private string[] getFormIds(int id)
        {
            var moduleForms = db.SysModuleForms.Where(s => s.ModuleID == id);
            string[] formIds = new string[moduleForms.Count()];

            int i = 0;
            foreach (SysModuleForm moduleForm in moduleForms)
            {
                formIds[i++] = moduleForm.FormID.ToString();
            }

            return formIds;
        }
    }
}
