﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using GroupLife;
using GroupLife.Common;

namespace GroupLife.Controllers
{
    public class SysUserTypeController : Controller
    {
        private IGLEntities db = new IGLEntities();
        private ControlAuth ca = new ControlAuth();
        private AuditTrails at = new AuditTrails();
        // GET: SysUserTypes
        public async Task<ActionResult> Index(string searchType)
        {
            ViewBag.allowedControls = ca.getAllowedControl("User Type", db);

            var sysUserType = from userType in db.SysUserTypes
                              select userType;

            if(!String.IsNullOrEmpty(searchType))
            {
                sysUserType = sysUserType.Where(s => s.Type.Contains(searchType));
            }
            if (!ca.CheckControl("User Type", 4, db))
            {
                return View("NotPermitted");
            }
            return View(await sysUserType.ToListAsync());
        }

        // GET: SysUserTypes/Details/5
        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysUserType sysUserType = await db.SysUserTypes.FindAsync(id);
            if (sysUserType == null)
            {
                return HttpNotFound();
            }
            return View(sysUserType);
        }

        // GET: SysUserTypes/Create
        public ActionResult Create()
        {
            if (!ca.CheckControl("User Type", 1, db))
            {
                return View("NotPermitted");
            }
            return PartialView("_Create");
        }

        // POST: SysUserTypes/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include = "TypeID,Type,Description")] SysUserType sysUserType)
        {
            if (ModelState.IsValid)
            {
                db.SysUserTypes.Add(sysUserType);
                await db.SaveChangesAsync();
                at.ActLogs(db, "Create", new SysUserType(), sysUserType);
                return Json(new { success = true });
            }
            
            return PartialView("_Create",sysUserType);
        }

        // GET: SysUserTypes/Edit/5
        public async Task<ActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysUserType sysUserType = await db.SysUserTypes.FindAsync(id);
            if (sysUserType == null)
            {
                return HttpNotFound();
            }
            if (!ca.CheckControl("User Type", 2, db))
            {
                return View("NotPermitted");
            }
            return PartialView("_Edit", sysUserType);
        }

        // POST: SysUserTypes/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include = "TypeID,Type,Description")] SysUserType sysUserType)
        {
            if (ModelState.IsValid)
            {
                SysUserType SYSUserType = db.SysUserTypes.Find(sysUserType.TypeID);
                at.ActLogs(db, "Editing", SYSUserType, sysUserType);
                db.Entry(sysUserType).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return Json(new { success = true
                });
            }
           
            return PartialView("_Edit",sysUserType);
        }

        // GET: SysUserTypes/Delete/5
        public async Task<ActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysUserType sysUserType = await db.SysUserTypes.FindAsync(id);
            if (sysUserType == null)
            {
                return HttpNotFound();
            }
            if (!ca.CheckControl("User Type", 3, db))
            {
                return View("NotPermitted");
            }
            return PartialView("_Delete",sysUserType);
        }

        // POST: SysUserTypes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            SysUserType sysUserType = await db.SysUserTypes.FindAsync(id);
            at.ActLogs(db, "Delete", sysUserType, new SysUserType());
            db.SysUserTypes.Remove(sysUserType);
            await db.SaveChangesAsync();
            return Json(new { success = true });
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
