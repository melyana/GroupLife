﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace GroupLife.Controllers
{
    public class ControllerBase : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            string controller = filterContext.HttpContext.Request.RequestContext.RouteData.Values["controller"].ToString();
            string action = filterContext.HttpContext.Request.RequestContext.RouteData.Values["action"].ToString();
            string pageName = controller + "/" + action;
            
            if (pageName != "User/Login" && pageName != "User/LoginAD" && pageName != "User/Logout") {
                HttpSessionStateBase session = filterContext.HttpContext.Session;
                var user = session["UserName"];

                if (((user == null) && (!session.IsNewSession)) || (session.IsNewSession))
                {
                    //send them off to the login page
                    var url = new UrlHelper(filterContext.RequestContext);
                    var loginUrl = url.Content("~/User/Logout");
                    
                    filterContext.HttpContext.Response.Redirect(loginUrl, true);
                }
            }
        }

    }
}