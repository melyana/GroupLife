﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using GroupLife;
using GroupLife.Models;
using GroupLife.Common;

namespace GroupLife.Controllers
{
    public class SysGroupController : Controller
    {
        private IGLEntities db = new IGLEntities();
        private ControlAuth ca = new ControlAuth();
        private static string[] formIds;

        // GET: /SysGroup/
        public async Task<ActionResult> Index(string searchGroupName)
        {
            ViewBag.allowedControls = ca.getAllowedControl("Group", db);

            var sysGroup = from sysgroup in db.SysGroups
                          select sysgroup;

            if (!String.IsNullOrEmpty(searchGroupName))
            {
                sysGroup = sysGroup.Where(s => s.GroupName.Contains(searchGroupName));
            }

            if (!ca.CheckControl("Group", 4, db))
            {
                return View("NotPermitted");
            }
            return View(await sysGroup.ToListAsync());
        }


        // GET: /SysGroup/Details/5
        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysGroup sysgroup = await db.SysGroups.FindAsync(id);
            if (sysgroup == null)
            {
                return HttpNotFound();
            }
            return View(sysgroup);
        }

        // GET: /SysGroup/Create
        public ActionResult Create()
        {
            SysGroupViewModel sysGroupViewModel = new SysGroupViewModel();
            sysGroupViewModel.SysModuleList = initializeModuleList();
            sysGroupViewModel.SysGroup = new SysGroup();
            sysGroupViewModel.SysModule = new SysModule();

            if (!ca.CheckControl("Group", 1, db))
            {
                return View("NotPermitted");
            }
            return PartialView("_Create", sysGroupViewModel);
        }

        // POST: /SysGroup/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(SysGroupViewModel sysGroupViewModel)
            //[Bind(Include="GroupID,GroupName,Description")] SysGroup sysgroup, 
            //PostedModules PostedModules)
        {
            //if (ModelState.IsValid)
            //{
                db.SysGroups.Add(sysGroupViewModel.SysGroup);
                await db.SaveChangesAsync();
                foreach (string moduleId in sysGroupViewModel.SysModuleList.PostedModules.ModuleIds)
                {
                    SysPrivilege priv = new SysPrivilege();
                    priv.GroupID = sysGroupViewModel.SysGroup.GroupID;
                    priv.ModuleID = int.Parse(moduleId);

                    db.SysPrivileges.Add(priv);
                    await db.SaveChangesAsync();
                }
                return Json(new { success = true });
            //}

            //return PartialView("_Create", sysGroupViewModel);
        }

        // GET: /SysGroup/Edit/5
        public async Task<ActionResult> Edit(int? GroupID)
        {
            if (GroupID == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysGroup sysgroup = await db.SysGroups.FindAsync(GroupID);
            SysGroupViewModel sysGroupViewModel = getGroupViewModel(sysgroup.GroupID);
            if (sysGroupViewModel.SysGroup == null)
            {
                return HttpNotFound();
            }

            if (!ca.CheckControl("Group", 2, db))
            {
                return View("NotPermitted");
            }
            return PartialView("_Edit", sysGroupViewModel);
        }

        // POST: /SysGroup/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(SysGroupViewModel sysGroupViewModel)
        {
            //if (ModelState.IsValid)
            //{
                db.Entry(sysGroupViewModel.SysGroup).State = EntityState.Modified;
                await db.SaveChangesAsync();
                db.SysPrivileges.RemoveRange(db.SysPrivileges.Where(c => c.GroupID == sysGroupViewModel.SysGroup.GroupID));
                await db.SaveChangesAsync();
                foreach (string moduleId in sysGroupViewModel.SysModuleList.PostedModules.ModuleIds)
                {
                    SysPrivilege priv = new SysPrivilege();
                    priv.GroupID = sysGroupViewModel.SysGroup.GroupID;
                    priv.ModuleID = int.Parse(moduleId);
                    db.SysPrivileges.Add(priv);
                    await db.SaveChangesAsync();
                }
                return Json(new { success = true });
            //}
            //return PartialView("_Edit", sysgroup);
        }

        // GET: /SysGroup/Delete/5
        public async Task<ActionResult> Delete(int? GroupID)
        {
            if (GroupID == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysGroup sysgroup = await db.SysGroups.FindAsync(GroupID);
            if (sysgroup == null)
            {
                return HttpNotFound();
            }

            if (!ca.CheckControl("Group", 3, db))
            {
                return View("NotPermitted");
            }
            return PartialView("_Delete", sysgroup);
        }

        // POST: /SysGroup/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int GroupID)
        {
            SysGroup sysgroup = await db.SysGroups.FindAsync(GroupID);
            db.SysPrivileges.RemoveRange(db.SysPrivileges.Where(c => c.GroupID == sysgroup.GroupID));
            await db.SaveChangesAsync();
            db.SysGroups.Remove(sysgroup);
            await db.SaveChangesAsync();
            return Json(new { success = true });
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        public async Task<ActionResult> Control(int GroupID)
        {
            var moduleIds = db.SysPrivileges.Where(s => s.GroupID == GroupID).Select(p => p.ModuleID).ToArray();
            var formIds = db.SysModuleForms.Where(x => moduleIds.Contains(x.ModuleID))
                .Select(s => s.FormID).ToArray();
            var formList = await db.SysForms.Where(x => formIds.Contains(x.Id)).Where(s => s.isParent == false).ToListAsync();
            SysGroupControlViewModel groupControl = new SysGroupControlViewModel();
            groupControl.SysForm = formList;
            groupControl.SysGroup = db.SysGroups.Find(GroupID);

            if (!ca.CheckControl("Group", 5, db))
            {
                return View("NotPermitted");
            }
            return PartialView("_Control", groupControl);
        }

        [HttpPost]
        public async Task<ActionResult> Control(SysGroupControlViewModel groupControl, FormCollection form)
        {
            formIds = null;
            SysPrivilegeControlViewModel sysPrivControlView = new SysPrivilegeControlViewModel();
            sysPrivControlView.SysControlListModel = initializeControlList();
            sysPrivControlView.SysGroup = groupControl.SysGroup;
            formIds = form.GetValues("selectedAddressesIds").ToArray();

            return PartialView("_ControlMultipleEdit", sysPrivControlView);
        }

        [HttpPost]
        public async Task<ActionResult> ControlMultipleEdit(SysPrivilegeControlViewModel sysPrivControlView)
        {

            foreach (string formId in formIds)
            {
                db.SysPrivilegeControls.RemoveRange(db.SysPrivilegeControls
                .Where(c => c.GroupID == sysPrivControlView.SysGroup.GroupID)
                .Where(x => x.FormID.ToString().Equals(formId)));
                await db.SaveChangesAsync();

                foreach(string controlId in sysPrivControlView.SysControlListModel.PostedConbtrol.ControlIds)
                {
                    SysPrivilegeControl privControl = new SysPrivilegeControl();
                    privControl.GroupID = sysPrivControlView.SysGroup.GroupID;
                    privControl.FormID = int.Parse(formId);
                    privControl.ControlID = int.Parse(controlId);

                    db.SysPrivilegeControls.Add(privControl);
                    await db.SaveChangesAsync();
                }
            }
            formIds = null;


            var moduleIds = db.SysPrivileges.Where(s => s.GroupID == sysPrivControlView.SysGroup.GroupID).Select(p => p.ModuleID).ToArray();
            var newformIds = db.SysModuleForms.Where(x => moduleIds.Contains(x.ModuleID))
                .Select(s => s.FormID).ToArray();
            var formList = await db.SysForms.Where(x => newformIds.Contains(x.Id)).Where(s => s.isParent == false).ToListAsync();
            SysGroupControlViewModel groupControl = new SysGroupControlViewModel();
            groupControl.SysForm = formList;
            groupControl.SysGroup = db.SysGroups.Find(sysPrivControlView.SysGroup.GroupID);

            return PartialView("_Control", groupControl);
        }

        public async Task<ActionResult> ControlEdit(int GroupID, int FormID)
        {
            SysPrivilegeControlViewModel sysPrivControlView = getPrivControlViewModel(GroupID, FormID);

            return PartialView("_ControlEdit", sysPrivControlView);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> ControlEdit(SysPrivilegeControlViewModel sysPrivControlView)
        {
            //if (ModelState.IsValid)
            //{
            
            db.SysPrivilegeControls.RemoveRange(db.SysPrivilegeControls
                .Where(c => c.GroupID == sysPrivControlView.SysGroup.GroupID)
                .Where(x => x.FormID == sysPrivControlView.SysForm.Id));
            await db.SaveChangesAsync();

            foreach (string controlId in sysPrivControlView.SysControlListModel.PostedConbtrol.ControlIds)
            {
                SysPrivilegeControl privControl = new SysPrivilegeControl();
                privControl.GroupID = sysPrivControlView.SysGroup.GroupID;
                privControl.FormID = sysPrivControlView.SysForm.Id;
                privControl.ControlID = int.Parse(controlId);

                db.SysPrivilegeControls.Add(privControl);
                await db.SaveChangesAsync();
            }
            return Json(new { success = true });
            //}

            //return PartialView("_Create", sysGroupViewModel);
        }
        private SysModuleListModel initializeModuleList()
        {
            SysModuleListModel model = new SysModuleListModel();
            model.AvailableModules = db.SysModules.ToList();
            model.SelectedModules = new List<SysModule>();

            return model;
        }

        private SysGroupViewModel getGroupViewModel(int id)
        {
            SysGroupViewModel model = new SysGroupViewModel();
            model.SysModuleList = new SysModuleListModel();
            model.SysModuleList.PostedModules = new PostedModules();

            string[] moduleIds = getModuleIds(id);

            if ( moduleIds != null && moduleIds.Any())
            {
                model.SysModuleList.PostedModules.ModuleIds = moduleIds;

                model.SysModuleList.SelectedModules = db.SysModules
                    .Where(x => moduleIds.Contains(x.ModuleID.ToString())).ToList();
            }

            model.SysGroup = db.SysGroups.Find(id);
            model.SysModuleList.AvailableModules = db.SysModules.ToList();

            return model;
        }

        private SysPrivilegeControlViewModel getPrivControlViewModel(int groupId, int formId)
        {
            SysPrivilegeControlViewModel model = new SysPrivilegeControlViewModel();
            model.SysControlListModel = new SysControlListModel();
            model.SysControlListModel.PostedConbtrol = new PostedControl();

            string[] controlIds = getControlIds(groupId, formId);

            if (controlIds != null && controlIds.Any())
            {
                model.SysControlListModel.PostedConbtrol.ControlIds = controlIds;

                model.SysControlListModel.SelectedControls = db.SysControls
                    .Where(x => controlIds.Contains(x.ControlID.ToString())).ToList();
            }

            model.SysGroup = db.SysGroups.Find(groupId);
            model.SysForm = db.SysForms.Find(formId);
            model.SysControlListModel.AvailableControls = db.SysControls.ToList();

            return model;
        }

        private string[] getModuleIds(int id)
        {
            List<SysPrivilege> privileges = db.SysPrivileges.Where(s => s.GroupID == id).ToList();
            string[] moduleIds = new string[privileges.Count()];

            int i = 0;
            foreach (SysPrivilege privilege in privileges)
            {
                moduleIds[i++] = privilege.ModuleID.ToString();
            }

            return moduleIds;
        }

        private string[] getControlIds(int groupId, int formId)
        {
            List<SysPrivilegeControl> privControls = db.SysPrivilegeControls
                .Where(s => s.GroupID == groupId)
                .Where(p => p.FormID == formId).ToList();
            string[] controlIds = new string[privControls.Count()];

            int i = 0;
            foreach (SysPrivilegeControl privControl in privControls)
            {
                controlIds[i++] = privControl.ControlID.ToString();
            }

            return controlIds;
        }

        private SysControlListModel initializeControlList()
        {
            SysControlListModel model = new SysControlListModel();
            model.AvailableControls = db.SysControls;

            return model;
        }
    }
}
