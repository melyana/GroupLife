﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Cryptography;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.DirectoryServices;

namespace GroupLife.Controllers
{

    public class UserController : Controller
    {
        private IGLEntities db = new IGLEntities();

        private static bool _isValid;
        private static string _username;
        private static string _encPassword;

        private static string _oldPassword;
        private static string _domainName;

        // GET: User
        public ActionResult Login()
        {
            ViewBag.Error = null;
            return View();
        }

        public ActionResult LoginAD()
        {
            return View();
        }

        public ActionResult ChangePassword()
        {
            return View();
        }

        [HttpPost, ActionName("ConfirmPass")]
        public ActionResult Confirm()
        {
            if (_isValid)
            {
                string loginType = Session["LoginType"].ToString();

                if (loginType == "N")
                {
                    SysUser sysuser = db.SysUsers
                            .Where(user => user.Username == _username)
                            .FirstOrDefault();

                    sysuser.Password = _encPassword;

                    try
                    {
                        db.SaveChanges();

                        return Redirect("/User/Logout");
                    }
                    catch (DbEntityValidationException e)
                    {
                        foreach (var eve in e.EntityValidationErrors)
                        {
                            Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                                eve.Entry.Entity.GetType().Name, eve.Entry.State);
                            foreach (var ve in eve.ValidationErrors)
                            {
                                Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                                    ve.PropertyName, ve.ErrorMessage);
                            }
                        }

                        ViewBag.Error = "Change Password Failed";
                    }
                }
                else if (loginType == "AD")
                {
                    try
                    {
                        LdapAuth la = new LdapAuth();
                        var res = la.ChangePasswordAD(_oldPassword, _encPassword, _domainName, _username);

                        return Redirect("/User/Logout");
                    }
                    catch (Exception)
                    {
                        ViewBag.Error = "Change Password Failed";
                    }
                }
            }
            else
            {
                ViewBag.Error = "Change Password Failed";
            }

            return View();
        }

        [HttpPost, ActionName("CancelPass")]
        public void Cancel()
        {
            _isValid = false;
            _username = null;
            _encPassword = null;

            _oldPassword = null;
            _domainName = null;
        }

        [HttpPost, ActionName("ChangePassword")]
        public ActionResult ChangePassPost(string oldPassword, string newPassword, string confirmPass)
        {
            if (ModelState.IsValid)
            {
                string loginType = Session["LoginType"].ToString();

                if (loginType == "N")
                {
                    ChangePassN(oldPassword, newPassword, confirmPass);
                }
                else if (loginType == "AD")
                {
                    ChangePassAD(oldPassword, newPassword, confirmPass);
                }
                string uname = Session["Username"].ToString(); ;
                SysUser sysuser = db.SysUsers.Where(x => x.Username.Equals(uname)).FirstOrDefault();
                sysuser.FirstLogin = false;
                db.Entry(sysuser).State = EntityState.Modified;
                db.SaveChanges();
            }

            return View();
        }

        public void ChangePassN(string oldPassword, string newPassword, string confirmPassword)
        {
            ViewBag.JS = null;
            AES_Cryptography crypto = new AES_Cryptography();

            string username = Session["UserName"].ToString();

            SysUser sysuser = db.SysUsers
                        .Where(user => user.Username == username)
                        .FirstOrDefault();

            if (crypto.decryptString(sysuser.Password) != oldPassword)
            {
                ViewBag.Error = "Old Password is incorrect";
            }
            else if (newPassword != confirmPassword)
            {
                ViewBag.Error = "New and Confirm Password doesn't match";
            }
            else if (newPassword == oldPassword)
            {
                ViewBag.Error = "Old and New Password must be different";
            }
            else
            {
                _isValid = true;
                _username = username;
                _encPassword = crypto.encryptString(newPassword);

                ViewBag.JS = "showModal()";
            }
        }

        public void ChangePassAD(string oldPassword, string newPassword, string confirmPassword)
        {
            string userName = Session["UserName"].ToString();

            LdapAuth la = new LdapAuth();

            if (!la.IsAuthenticated(userName, oldPassword))
            {
                ViewBag.Error = "Old Password is incorrect";
            }
            else if (newPassword != confirmPassword)
            {
                ViewBag.Error = "New and Confirm Password don't match";
            }
            else if (newPassword == oldPassword)
            {
                ViewBag.Error = "Old and New Password must be different";
            }
            else
            {
                _isValid = true;
                _username = userName;
                _encPassword = newPassword;

                _oldPassword = oldPassword;

                ViewBag.JS = "showModal()";
            }
        }

        [HttpPost, ActionName("Login")]
        public ActionResult LoginPost(string username, string password)
        {
            if (ModelState.IsValid)
            {

                SysUser sysuser = db.SysUsers
                        .Where(user => user.Username == username)
                        .FirstOrDefault();
                if (username != null)
                {
                    if (sysuser.RestoreLimit != null && DateTime.Now >= sysuser.RestoreLimit)
                    {
                        sysuser.LockedStatus = false;
                        sysuser.RestoreLimit = null;
                        sysuser.LogAttempt = null;
                        db.Entry(sysuser).State = EntityState.Modified;
                        db.SaveChanges();
                    }
                    if (sysuser.LockedStatus == false || sysuser.LockedStatus == null)
                    {
                        AES_Cryptography crypto = new AES_Cryptography();

                        if (sysuser == null)
                        {
                            ViewBag.Error = "Invalid Username";

                        }
                        else
                        {
                            
                           
                            if (crypto.decryptString(sysuser.Password) == password)
                            {
                                Session["UserName"] = sysuser.Username;
                                Session["GroupID"] = sysuser.GroupID;
                                //Session["Domain"] = sysuser.Domain;
                                Session["Name"] = sysuser.Name;
                                Session["Type"] = sysuser.Type;
                                Session["LoginType"] = "N";
                             

                                if (sysuser.LogAttempt != null)
                                {
                                    sysuser.LogAttempt = null;
                                }
                                
                                if (sysuser.FirstLogin == true)
                                {
                                    
                                    return RedirectToAction("ChangePassword", "User");
                                }

                                db.Entry(sysuser).State = EntityState.Modified;
                                db.SaveChanges();
                                return RedirectToAction("Index", "Home");
                               
                            }
                            else
                            {
                                ViewBag.Error = "Invalid Password";
                                if (sysuser.LogAttempt == null)
                                {
                                    sysuser.LogAttempt = 1;
                                }
                                else
                                {
                                    sysuser.LogAttempt += 1;
                                }
                                if (sysuser.LogAttempt == 3)
                                {
                                    DateTime lockedDate = DateTime.Now;
                                    lockedDate.AddDays(1);
                                    sysuser.RestoreLimit = lockedDate;
                                    sysuser.LockedStatus = true;
                                    ViewBag.Error = "Your Account has been locked for a day \n Please contact Administrator to unlock your account.";
                                }
                                db.Entry(sysuser).State = EntityState.Modified;
                                db.SaveChanges();
                            }
                        }
                    }
                    else
                    {
                        ViewBag.Error = "Your Account has been locked for a day \n Please contact Administrator to unlock your account.";
                    }

                }
                else
                {
                    ViewBag.Error = "Invalid username or password";

                }
            }

            return View();
        }

        [HttpPost, ActionName("LoginAD")]
        public ActionResult LoginPostAD(string username, string password)
        {
            if (ModelState.IsValid)
            {
                if (username != null)
                {
                    try
                    {
                        SysUser sysuser = db.SysUsers
                            .Where(user => user.Username == username)
                            .FirstOrDefault();

                        if (sysuser != null)
                        {
                            LdapAuth adAuth = new LdapAuth();

                            if (adAuth.IsAuthenticated(username, password))
                            {
                                //auth success
                                ViewBag.Result = "Authentication succeed";

                                Session["UserName"] = sysuser.Username;
                                Session["GroupID"] = sysuser.GroupID;
                                Session["Domain"] = adAuth.GetDomain();
                                Session["Name"] = sysuser.Name;
                                Session["Type"] = sysuser.Type;
                                Session["LoginType"] = "AD";

                                return RedirectToAction("Index", "Home");
                            }
                            else
                            {
                                //auth failed
                                ViewBag.Error = "Authentication did not succeed. Check user name and password";
                            }
                        }
                        else
                        {
                            ViewBag.Error = "Your username doesn't registered in database";
                        }
                    }
                    catch (Exception err)
                    {
                        ViewBag.Error = err.Message;
                    }
                }
                else
                {
                    ViewBag.Error = "Invalid username or password";
                }
            }

            return View();
        }

        public ActionResult Logout()
        {
            Session.Clear();
            Session.RemoveAll();
            Session.Abandon();

            return RedirectToAction("Login", "User");
        }

    }
}