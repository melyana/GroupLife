﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using GroupLife;

namespace GroupLife.Controllers
{
    public class SysPrivilegeControlController : Controller
    {
        private IGLEntities db = new IGLEntities();

        // GET: /SysPrivilegeControl/
        public async Task<ActionResult> Index()
        {
            var sysprivilegecontrols = db.SysPrivilegeControls.Include(s => s.SysControl).Include(s => s.SysGroup);
            return View(await sysprivilegecontrols.ToListAsync());
        }

        // GET: /SysPrivilegeControl/Details/5
        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysPrivilegeControl sysprivilegecontrol = await db.SysPrivilegeControls.FindAsync(id);
            if (sysprivilegecontrol == null)
            {
                return HttpNotFound();
            }
            return View(sysprivilegecontrol);
        }

        // GET: /SysPrivilegeControl/Create
        public ActionResult Create()
        {
            ViewBag.ControlID = new SelectList(db.SysControls, "ControlID", "Name");
            ViewBag.GroupID = new SelectList(db.SysGroups, "GroupID", "GroupName");
            return PartialView("_Create");
        }

        // POST: /SysPrivilegeControl/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include="PrivControlID,GroupID,ControlID,Status")] SysPrivilegeControl sysprivilegecontrol)
        {
            if (ModelState.IsValid)
            {
                db.SysPrivilegeControls.Add(sysprivilegecontrol);
                await db.SaveChangesAsync();
                return Json(new { success = true });
            }

            ViewBag.ControlID = new SelectList(db.SysControls, "ControlID", "Name", sysprivilegecontrol.ControlID);
            ViewBag.GroupID = new SelectList(db.SysGroups, "GroupID", "GroupName", sysprivilegecontrol.GroupID);
            return PartialView("_Create", sysprivilegecontrol);
        }

        // GET: /SysPrivilegeControl/Edit/5
        public async Task<ActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysPrivilegeControl sysprivilegecontrol = await db.SysPrivilegeControls.FindAsync(id);
            if (sysprivilegecontrol == null)
            {
                return HttpNotFound();
            }
            ViewBag.ControlID = new SelectList(db.SysControls, "ControlID", "Name", sysprivilegecontrol.ControlID);
            ViewBag.GroupID = new SelectList(db.SysGroups, "GroupID", "GroupName", sysprivilegecontrol.GroupID);
            return PartialView("_Edit", sysprivilegecontrol);
        }

        // POST: /SysPrivilegeControl/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include="PrivControlID,GroupID,ControlID,Status")] SysPrivilegeControl sysprivilegecontrol)
        {
            if (ModelState.IsValid)
            {
                db.Entry(sysprivilegecontrol).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return Json(new { success = true });
            }
            ViewBag.ControlID = new SelectList(db.SysControls, "ControlID", "Name", sysprivilegecontrol.ControlID);
            ViewBag.GroupID = new SelectList(db.SysGroups, "GroupID", "GroupName", sysprivilegecontrol.GroupID);
            return PartialView("_Edit", sysprivilegecontrol);
        }

        // GET: /SysPrivilegeControl/Delete/5
        public async Task<ActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysPrivilegeControl sysprivilegecontrol = await db.SysPrivilegeControls.FindAsync(id);
            if (sysprivilegecontrol == null)
            {
                return HttpNotFound();
            }
            return PartialView("_Delete", sysprivilegecontrol);
        }

        // POST: /SysPrivilegeControl/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            SysPrivilegeControl sysprivilegecontrol = await db.SysPrivilegeControls.FindAsync(id);
            db.SysPrivilegeControls.Remove(sysprivilegecontrol);
            await db.SaveChangesAsync();
            return Json(new { success = true });
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
