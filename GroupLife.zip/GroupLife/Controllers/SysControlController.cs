﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using GroupLife;

namespace GroupLife.Controllers
{
    public class SysControlController : Controller
    {
        private IGLEntities db = new IGLEntities();

        // GET: /SysControl/
        public async Task<ActionResult> Index(string searchControlName)
        {
            var sysControl = from control in db.SysControls
                            select control;

            if (!String.IsNullOrEmpty(searchControlName))
            {
                sysControl = sysControl.Where(s => s.Name.Contains(searchControlName));
            }
            return View(await sysControl.ToListAsync());
        }

        // GET: /SysControl/Details/5
        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysControl syscontrol = await db.SysControls.FindAsync(id);
            if (syscontrol == null)
            {
                return HttpNotFound();
            }
            return View(syscontrol);
        }

        // GET: /SysControl/Create
        public ActionResult Create()
        {
            return PartialView("_Create");
        }

        // POST: /SysControl/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include="ControlID,Name,Status")] SysControl syscontrol)
        {
            if (ModelState.IsValid)
            {
                db.SysControls.Add(syscontrol);
                await db.SaveChangesAsync();
                return Json(new { success = true });
            }

            return PartialView("_Create", syscontrol);
        }

        // GET: /SysControl/Edit/5
        public async Task<ActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysControl syscontrol = await db.SysControls.FindAsync(id);
            if (syscontrol == null)
            {
                return HttpNotFound();
            }
            return PartialView("_Edit", syscontrol);
        }

        // POST: /SysControl/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include="ControlID,Name,Status")] SysControl syscontrol)
        {
            if (ModelState.IsValid)
            {
                db.Entry(syscontrol).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return Json(new { success = true });
            }
            return PartialView("_Edit", syscontrol);
        }

        // GET: /SysControl/Delete/5
        public async Task<ActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysControl syscontrol = await db.SysControls.FindAsync(id);
            if (syscontrol == null)
            {
                return HttpNotFound();
            }
            return PartialView("_Delete", syscontrol);
        }

        // POST: /SysControl/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            SysControl syscontrol = await db.SysControls.FindAsync(id);
            db.SysControls.Remove(syscontrol);
            await db.SaveChangesAsync();
            return Json(new { success = true });
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
