﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GroupLife.Domain;
using GroupLife.Models;
using GroupLife;

namespace GroupLife.Controllers
{
    public class NavbarController : Controller
    {
        //
        // GET: /Navbar/
        private IGLEntities db = new IGLEntities();

        [ControllerBase]
        public ActionResult Index()
        {
            var groupId = Session["GroupID"] != null || Session["GroupID"].ToString() != ""
                ? Session["GroupID"].ToString()
                : "0";
            //  var parentForms = db.SysForms.Where(x => x.isParent == true);
            SysForm sysform = new SysForm();
            var moduleIds = db.SysPrivileges.Where(x => x.GroupID.ToString() == groupId).Select(p => p.ModuleID).ToArray();
            var formIds = db.SysModuleForms.Where(x => moduleIds.Contains(x.ModuleID)).Select(p => p.FormID).ToArray();
            var forms = db.SysForms.Where(x => formIds.Contains(x.Id))
                        .OrderBy(x =>x.sequence)
                        .ToList();

           
            var parentIds = forms.Select(s => s.parentId).Distinct().ToArray();
            var parentForm = db.SysForms.Where(s => parentIds.Contains(s.Id)).ToList();
            forms.AddRange(parentForm);

            //forms.Concat(parentForms);
            return PartialView("_Navbar", forms);
        }
	}
}