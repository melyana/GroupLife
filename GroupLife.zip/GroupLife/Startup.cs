﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(GroupLife.Startup))]
namespace GroupLife
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
